pytest plugin for adding to the PYTHONPATH from command line or configs.


