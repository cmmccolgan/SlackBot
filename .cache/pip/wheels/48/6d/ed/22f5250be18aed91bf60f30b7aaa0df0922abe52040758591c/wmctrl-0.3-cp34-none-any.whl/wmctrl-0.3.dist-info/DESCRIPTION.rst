A tool to programmatically control windows inside X


